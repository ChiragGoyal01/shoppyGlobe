import { useSelector, useDispatch } from "react-redux";
import CartItem from "./CartItem";

const Cart = () => {
  const cartItems = useSelector((state) => state.cart.items);

  if (cartItems.length === 0) return <p>Your cart is empty.</p>;

  return (
    <div className="cart" style={{backgroundColor:"red"}}>
      {cartItems.map((item) => (
        <CartItem key={item.id} item={item} />
      ))}
    </div>
  );
};

export default Cart;
