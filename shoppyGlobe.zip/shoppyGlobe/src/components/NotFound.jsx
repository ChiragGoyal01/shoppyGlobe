const NotFound = () => {
    return <p>404 - Page Not Found</p>;
  };
  
  export default NotFound;
  