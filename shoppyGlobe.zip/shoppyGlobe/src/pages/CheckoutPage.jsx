import { useSelector } from "react-redux";

const CheckoutPage = () => {
  const cartItems = useSelector((state) => state.cart.items);

  const totalAmount = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

  return (
    <div className="checkout-page">
      <h1>Checkout</h1>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          <ul>
            {cartItems.map((item) => (
              <li key={item.id}>
                {item.title} - {item.quantity} x {item.price} USD
              </li>
            ))}
          </ul>
          <h3>Total: {totalAmount} USD</h3>
        </div>
      )}
      <button>Proceed to Payment</button>
    </div>
  );
};

export default CheckoutPage;
