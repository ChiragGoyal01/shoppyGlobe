import Cart from "../components/Cart";

const CartPage = () => {
  return (
    <div className="cart-page">
      <h1 style={{textAlign:"center", padding:'10px'}}>Your Cart</h1>
      <Cart />
    </div>
  );
};

export default CartPage;
