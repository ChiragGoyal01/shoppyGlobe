// src/hooks/useFetchProducts.js
import { useState, useEffect } from "react";
import { API_BASE_URL } from "../config";

const useFetchProducts = () => {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/products`);
        const data = await response.json();
        setProducts(data);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch products');
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return { products, error, loading };
};

export default useFetchProducts;
