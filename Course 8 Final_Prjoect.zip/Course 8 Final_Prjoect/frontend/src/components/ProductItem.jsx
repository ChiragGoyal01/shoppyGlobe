import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";
import { Link } from "react-router-dom";

const ProductItem = ({ product }) => {
  const dispatch = useDispatch();

  return (
    <div className="card">
      <h3>{product.title}</h3>
      <p>{product.price} USD</p>
      <button onClick={() => dispatch(addToCart(product))}>Add to Cart</button> <br /><br />
      <Link className="view" style={{backgroundColor:"red",color:"#fff",padding:"0.8rem 1.5rem",border:"none",borderRadius:"6px",fontSize:"1rem",cursor:"pointer",transition:"background-color 0.3s ease"}} to={`/product/${product.id}`}>View Details</Link>
    </div>
  );
};

export default ProductItem;

