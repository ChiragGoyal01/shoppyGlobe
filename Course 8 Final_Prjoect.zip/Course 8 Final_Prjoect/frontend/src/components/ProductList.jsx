import ProductItem from "./ProductItem";
import useFetchProducts from "../hooks/useFetchProducts";

const ProductList = () => {
  const { products, error, loading } = useFetchProducts();

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error fetching products: {error}</p>;

  return (
    <div className="product_list" style={{display:"flex",flexWrap:"wrap",alignItems: 'center', justifyContent: 'space-around'}}>
      {products.map((product) => (
        <ProductItem key={product.id} product={product} />
      ))}
    </div>
  );
};

export default ProductList;
